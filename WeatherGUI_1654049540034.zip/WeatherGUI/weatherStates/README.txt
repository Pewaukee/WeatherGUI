this folder houses the different type of 
weather states as pictures to be used as 
backgrounds whenever the submit button is called